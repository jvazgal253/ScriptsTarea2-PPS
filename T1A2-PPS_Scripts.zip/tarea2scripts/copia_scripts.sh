#!/bin/bash
#Comprobamos si se ha introducido algún parámetro
if [ $# -eq 0 -o $# -gt 1 ]; then
    echo "Introduce un parámetro"
    exit
else
    if [ -d $1 ]; then #Comprobamos si es un directorio correcto.
        echo "El directorio es correcto."
        echo "Creando archivo comprimido..."
        sleep 2
        tar -cvf copia_scripts_$(date +%d%m%Y).tar $1
        echo "COMPLETADO"
    else
        echo "El directorio $1 no existe"
        exit
    fi
fi