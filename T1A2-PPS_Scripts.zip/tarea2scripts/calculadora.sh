#! /bin/bash
#En este ejericio podemos hacer uso de las funciones para facilitar la estructura del CASE
numcheck(){
    #Pedimos los valores por teclado
    echo ""
    read -p "Dame el primer número: " n1
    echo ""
    read -p "Dame el segundo número: " n2
    echo ""
    #Comprobaremos si alguno de los campos está vacío o si es un valor erroneo
    #Los errores (junto a su fecha) los enviaremos a sus correspondientes archivos
    if ([ "$n1" -ne "$n1" ] || [ "$n2" -ne "$n2" ]) 2>>errores.txt && date >>errores.txt; then
        echo "ERROR. El valor está vacío o no es un número"
        exit 1
    fi
}
#Ahora crearemos las funciones de las operaciones
suma(){
    numcheck
    var=$(echo "scale=2; $n1+$n2" | bc)
    echo "El resultado es: $var"
    echo ""
}
resta(){
    numcheck
    var=$(echo "scale=2; $n1-$n2" | bc)
    echo "El resultado es: $var"
    echo ""
}
mult(){
    numcheck
    var=$(echo "scale=2; $n1*$n2" | bc)
    echo "El resultado es: $var"
    echo ""
}
div(){
    numcheck
    var=$(echo "scale=2; $n1/$n2" | bc)
    echo "El resultado es: $var"
    echo ""
}
#Para que no salga del menú hasta elegir el 5, hacemos un bucle While.
while true; do
    echo "Elige una opción:"
    echo "1)SUMAR"
    echo "2)RESTAR"
    echo "3)MULTIPLICAR"
    echo "4)DIVIDIR"
    echo "5)SALIR -->"
    read operacion #Leemos el valor introducido

case $operacion in #Hacemos un case con cada una de las opciones
    1) suma ;;
    2) resta ;;
    3) mult ;;
    4) div ;;
    5) echo "Has salido de la calculadora."
       exit ;;
    *) echo "La opción es incorrecta. Para salir puedes pulsar 5..."
       sleep 3s
       echo "" ;;
    esac
done
