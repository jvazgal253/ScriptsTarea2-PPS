#! /bin/bash
#Creamos las variables que almacenen los datos
anio=`date "+%Y"` 
var=$(($anio-$1))

if [ $# -le 0 ] || [ $# -gt 1 ]; then #Comprobamos que se inserta únicamente un parámetro
    echo "Introduce únicamente un parámetro"
else
    if [ $var -lt 1960 ] || [ $var -gt $anio ]; then #Ajustamos el filtro de los valores insertados
    echo "Introduce un año válido"
    else
        echo "La edad Introducida es $1 años"
            sleep 1
        echo "Calculando década..."
            sleep 3
        #Ubicamos el parámetro definido entre los valores según la década.
        if [ $var -ge 1961 ] && [ $var -le 1970 ];then
            echo "Ubica la década de los 60"
        elif [ $var -ge 1971 ] && [ $var -le 1980 ];then
            echo "Ubica la década de los 70"
        elif [ $var -ge 1981 ] && [ $var -le 1990 ];then
            echo "Ubica la década de los 80"
        elif [ $var -ge 1991 ] && [ $var -le 2000 ];then
            echo "Ubica la década de los 90"
        elif [ $var -ge 2001 ] && [ $var -le 2010 ];then
            echo "Ubica la década de los 2000"
        elif [ $var -ge 2011 ] && [ $var -le 2020 ];then
            echo "Ubica la década de los 2010"
        else
            echo "Ubica la década actual"
        fi
    fi

fi