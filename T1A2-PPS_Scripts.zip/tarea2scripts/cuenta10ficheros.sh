#!/bin/bash
#Comprobamos que se nos pasa al menos un parámetro
if [ $# -ge 1 ]; then
    if [ -d $1 ] #Compruebo que el parametro pasado es un directorio
    then
        numf=$(find $1 -type f |wc -l) #Buscamos todos los archivos del parámetro y los contamos

        if [ $numf -ge 10 ]; then #Comprobamos si hay 10 o más ficheros regulares
            echo "El directorio $1 contiene 10 o más ficheros regulares"
        else
            echo "El directorio $1 contiene menos de 10 ficheros regulares"
        fi
    else
        echo "ERROR. El parámetro pasado no es un directorio válido"
        sleep 2
        exit 2
    fi
else
    echo "ERROR. Se espera al menos 1 parámetro que sea un directorio válido"
    sleep 2
    exit 1
fi