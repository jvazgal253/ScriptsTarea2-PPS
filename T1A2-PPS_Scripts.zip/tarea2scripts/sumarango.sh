#! /bin/bash
echo "INTRODUZCA DOS NÚMEROS."
read -p "Introduce el primer número: " num1
read -p "Introduce el segundo número: " num2
if ([ $num1 -ne $num1 ] || [ $num2 -ne $num2 ])2>/dev/null; then
    echo "ERROR. Comprueba que ambos valores son números y/o no están vacíos"
else
    if [ $num1 -gt $num2 ]; then #Comprobamos el orden de los valores para no generar un mal bucle.
        #Creamos variables nuevas con los valores almacenados en orden inverso.
        var1=$num2
        var2=$num1
        #Hacemos un bucle FOR para realizar la suma de rango.
        resultado=0
        for i in $(seq $var1 $var2)
        do
            resultado=$(expr $resultado + $i)
        done
            echo "" #Podemos usar clear si estéticamente lo preferimos
            echo "El resultado es $resultado"
            echo "Resultado de sumar: "`seq -s "+" $var1 $var2` #Mostramos lo pedido por el ejercicio en pantalla
    else
        #En caso de que estuviesen en el orden correcto, haremos lo mismo pero con los valores originales
        resultado=0
        for i in $(seq $num1 $num2)
        do
            resultado=$(expr $resultado + $i)
        done
            echo "" #Podemos usar clear si estéticamente lo preferimos
            echo "El resultado es $resultado"
            echo "Resultado de sumar: "`seq -s "+" $num1 $num2` #Mostramos lo pedido por el ejercicio en pantalla
    fi
fi