#! /bin/bash
#Pedimos por pantalla un valor
read -p "Introduce tu año de nacimiento para saber tu horóscopo Chino: " anio
year=`date "+%Y"` #Creamos una variable con el año actual (Para que quede mejor)
if ! [ $anio -eq $anio ] 2>/dev/null; then #Comprobamos el estado del valor pedido
    echo "El valor está vacío o no es un número."
exit
else
    if [ $anio -lt 1950 -o $anio -gt $year ]; then #Filtramos el valor
    echo "El año de nacimiento no es válido"
    else
        var=$(($anio%12)) #Creamos la variable almacenando en ella el resto de la división del valor entre 12
        case "$var" in #Usamos el resultado de dicha variable en el CASE
        0) echo "Te corresponde el Horoscopo Chino de la Rata";;
        1) echo "Te corresponde el Horoscopo Chino del Buey";;
        2) echo "Te corresponde el Horoscopo Chino del Tigre";;
        3) echo "Te corresponde el Horoscopo Chino del Conejo";;
        4) echo "Te corresponde el Horoscopo Chino del Dragón";;
        5) echo "Te corresponde el Horoscopo Chino de la Serpiente";;
        6) echo "Te corresponde el Horoscopo Chino del Caballo";;
        7) echo "Te corresponde el Horoscopo Chino de la Cabra";;
        8) echo "Te corresponde el Horoscopo Chino del Mono";;
        9) echo "Te corresponde el Horoscopo Chino del Gallo";;
        10) echo "Te corresponde el Horoscopo Chino del Perro";;
        11) echo "Te corresponde el Horoscopo Chino del Cerdo";;
        *) echo "Error. Inténtelo de nuevo.";;
        esac
    fi
fi