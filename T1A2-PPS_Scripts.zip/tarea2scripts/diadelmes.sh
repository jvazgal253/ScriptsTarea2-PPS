#! /bin/bash
#Creamos la variable para almacenar el número del mes en el que estamos.
mes=`date "+%m"`
case $mes in #Y con CASE haremos para cada caso una respuesta.
    1) echo "Estamos en enero. Tiene 31 días";;
    2) echo "Estamos en febrero. Tiene 28 días";;
    3) echo "Estamos en marzo. Tiene 31 días";;
    4) echo "Estamos en abril. Tiene 30 días";;
    5) echo "Estamos en mayo. Tiene 31 días";;
    6) echo "Estamos en junio. Tiene 30 días";;
    7) echo "Estamos en julio. Tiene 31 días";;
    8) echo "Estamos en agosto. Tiene 31 días";;
    9) echo "Estamos en septiembre. Tiene 30 días";;
    10) echo "Estamos en octubre. Tiene 31 días";;
    11) echo "Estamos en noviembre. Tiene 30 días";;
    12) echo "Estamos en diciembre. Tiene 31 días";;
    *) echo "Deberías ajustar la fecha porque solo hay 12 meses";;
esac