#! /bin/bash
read -p "Introduce un número: " num
if ! [ "$num" -eq "$num" ] 2>/dev/null; then
    #Comprobamos si no se ha introducido un número o parámetro
    echo "El parámetro está vacío o no es un número"
    exit 1
else
    var=$((num%10)) #Realizamos la operación 
    if [ $var -eq 0 ]; then #Comprobamos si el número es múltiplo de 10.
        echo "El número es múltiplo de 10"
    else
        echo "El número NO es múltiplo de 10"
    fi
    
fi
