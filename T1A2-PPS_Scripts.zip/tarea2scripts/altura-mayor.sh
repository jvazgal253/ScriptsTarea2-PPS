#!/bin/bash
#Comprobamos que se nos pasa al menos un parámetro
if [ $# -ge 1 ]; then
    if [ -d $1 ] #Compruebo que el parametro pasado es un directorio
    then
        cont=0
        for i in `ls $1` #Recorro todos los elementos del directorio
        do
            if [ -f $i ]; then #Compruebo si el elemento es un fichero regular
            (($cont++)) #Aumentamos el contador de ficheros regulares
            else
            echo "fallo?"
            fi
        done

        if [ $cont -ge 10 ]; then #Comprobar si hay 10 o más ficheros regulares
            echo "El directorio $1 contiene 10 o más ficheros regulares"
        else
            echo "El  directorio $1 contiene menos de 10 ficheros regulares"
        fi
    else
        echo "ERROR. El parámetro pasado no es un directorio válido"
        sleep 2
        exit 2
    fi
else
    echo "ERROR. Se espera al menos 1 parámetro que sea un directorio válido"
    sleep 2
    exit 1
fi
echo "FIN DEL PROGRAMA"
#read -p "Pulse INTRO para continuar"
#clear