#!/bin/bash
# Creamos la función para el siguiente usuario
usuariosys() {
    if id "$usuario" >> ejer_uids.log 2>&1; then
        echo "Usuario: $usuario"
        id $usuario | cut -d ',' -f1
        exit 0
    else
        echo "El usuario $1 no existe"
        exit 3
    fi
}
# Comprobamos si se han introducido parametros
if [ $# -eq 0 -o $# -gt 1 ]; then
    echo "Introduce un parámetro (únicamente)"
    exit 1
else
    #Comprobamos que exista el usuario
    if id "$1" >> ejer_uids.log 2>&1; then #Añadimos los datos a un archivo .log
        echo "Usuario: $1"
        id $1 | cut -d ',' -f1
        echo "Su directorio es home/$1"
        sleep 2s
        echo ""
        until false; do #Creamos un bucle con un case dentro para manejar las opciones
            read -p "Si desea buscar otro usuario en el sistema pulse S, en caso contrario pulse N para salir: " opcion
            case "$opcion" in
                S | s) read -p "Introduzca el nombre de usuario: " usuario
                       usuariosys ;;
                N | n) echo "Saliendo del programa..."
                       sleep 2
                       exit ;;
                *) echo "ERROR. Las opciones son S(si) o N(no)"
                       exit ;;
            esac
        done
    else
        echo "El usuario $1 no existe"
        exit 3
    fi
fi